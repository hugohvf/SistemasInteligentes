# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 14:27:10 2020

  Atividade 2 Sistemas Inteligentes
@author: Hugo, Lucas, Caio, Bia
"""
import principal_mlp_predicao_minibatch as minibatch
import principal_mlp_predicao_batch as batch
#
batchSize = int(input("Insira o tamanho do batch para o treinamento por minibatch:\n"))
print('\nPredição do minibatch com tamanho de {}:'.format(batchSize))
minibatch.predict(2, batchSize)

print('\nPredição do batch com passo de 5:')
batch.predict(5)
print('\nPredição do minibatch com passo de 5:')
minibatch.predict(5)

print('\nPredição do batch com passo de 10:')
batch.predict(10)
print('\nPredição do minibatch com passo de 10:')
minibatch.predict(10)

print('\nPredição do batch com passo de 52:')
batch.predict(52)
print('\nPredição do minibatch com passo de 52:')
minibatch.predict(52)
